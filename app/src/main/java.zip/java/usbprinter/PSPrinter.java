package usbprinter;

import java.io.IOException;
import java.io.InputStream;

import bmpinterface.PngTranslator;
import bmpinterface.Translator;

/**
 * Created by diego on 11-11-15.
 */
public class PSPrinter extends USBPrinter{

    public PSPrinter(InputStream is) {
        super(is);
    }

    public byte[] print(){
        translator = new PngTranslator(fileData);
        return printFile();
    }

    public byte[] printFile(){
        messageData = new byte[translator.getPCLSize()*2]; //GETPSSIZE
        addUEL("POSTSCRIPT");
        addText("%!PS-Adobe-3.0\r");

        addText("50 50 translate\r");
        translator.addPSImage(this);
        addText("showpage\r");
        addText("\004");
        return messageData;
    }

}
