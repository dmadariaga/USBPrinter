package usbprinter;

import java.io.IOException;
import java.io.InputStream;

import bmpinterface.Translator;

/**
 * Created by diego on 09-09-15.
 */
public abstract class USBPrinter {
    protected Translator translator;
    protected byte[] fileData;
    protected byte[] messageData;
    protected int cursor;

    public USBPrinter(InputStream is) {
        try {
            int len = is.available();
            fileData = new byte[len];
            is.read(fileData);
        }
        catch (IOException e){
            e.printStackTrace();
        }
        cursor = 0;
    }

    public void add(byte b) {
        messageData[cursor] = b;
        cursor++;
    }


    public void add(byte[] b){
        for (int i=0; i< b.length; i++){
            add(b[i]);
        }
    }

    public void add(double d) { add((byte) (d+0.5)); }

    public void add(int i) {
        add((byte) i);
    }

    public void addText(String text){
        byte[] byteText = text.getBytes();
        for (int i=0; i<byteText.length; i++){
            add(byteText[i]);
        }
    }

    public void addESC(){
        add(27);  // <ESC> ascii
    }

    public void addUEL(String language){ //Universal Exit Language, control to PJL
        addESC();
        addText("%-12345X");
        addText("@PJL Enter Language = " + language);
        add((byte)0x0D);
        add((byte)0x0A);
    }
}
