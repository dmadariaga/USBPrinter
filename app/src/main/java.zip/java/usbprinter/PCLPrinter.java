package usbprinter;

import java.io.IOException;
import java.io.InputStream;

import bmpinterface.BmpTranslator;
import bmpinterface.PngTranslator;
import bmpinterface.Translator;

public class PCLPrinter extends USBPrinter {
    private int unitOfMeasure;
    private int dotsPerInch;
    private int pageSize;
    private int xPosition;
    private int yPosition;
    private double xScale;
    private double yScale;
    private int dataImage[];

    public PCLPrinter(InputStream is) {
        super(is);
        setDefaultValues();
    }

    public void setDefaultValues(){
        unitOfMeasure = 300;
        dotsPerInch = 75;
        pageSize = 2;
        xPosition = yPosition = 0;
        xScale = yScale = 1;
        int defaultData[] = {2, 3, 0, 8, 8, 8};
        setDataImage(defaultData);
    }

    public byte[] print(){
        translator = new PngTranslator(fileData);
        return printFile();
    }

    public void setxPosition(int x, int y){
        xPosition = x;
        yPosition = y;
    }

    public void setScale(int x, int y){
        xScale = x;
        yScale = y;
    }

    public void setPageSize(int p){
        pageSize = p;       //2 - Letter (8.5" x 11")
                            //3 - Legal (8.5" x 14")
                            //6 - Ledger (11" x 17")
                            //25 - A5 paper (148mm x 210mm)
                            //26 - A4 paper (210mm x 297mm)
                            //27 - A3 (297mm x 420mm)
                            //45 - JIS B5 paper (182mm x 257mm)
                            //46 - JIS B4 paper (250mm x 354mm)
                            //71 - Hagaki postcard (100mm x 148mm)
                            //72 - Oufuku-Hagaki postcard (200mm x 148mm)
                            //80 - Monarch Envelope (3 7/8" x 7 1/2")
                            //81 - Commercial Envelope 10 (4 1/8" x 9 1/2")
                            //90 - International DL (110mm x 220mm)
                            //91 - International C5 (162mm x 229mm)
                            //100 - International B5 (176mm x 250mm)
                            //101 - Custom (size varies with printer)
    }
    public void setUnitOfMeasure(int u){
        unitOfMeasure = u;  //Range = 96, 100, 120, 144, 150, 160, 180, 200, 225, 240, 288, 300, 360,
                            // 400, 450, 480, 600, 720, 800, 900, 1200, 1440, 1800, 2400, 3600, 7200
    }

    public void setRasterGraphicsResolution(int d){
        dotsPerInch = d;    //Range = 75, 100, 150, 200, 300, 600
    }

    public void setDataImage(int[] data){
        dataImage = data;
    }

    public byte[] printFile() {
        messageData = new byte[translator.getPCLSize()];
        addUEL("PCL");
        resetPrinter();
        addUnitOfMeasure();  //Unit-of-Measure (600 PCL units per inch)
        addPageSize();
        addESC();
        addText("*p0P");    //Push (save) palette from the pallete stack
        addPosition();      //Postion X,Y in PCL units (units of measure)
        addConfigureImageData();
        addDotsPerInch();
        addImageFile();
        addESC();
        addText("*rC");     //End raster graphics
        addESC();
        addText("*p1P");    //Pop (restore) palette from the pallete stack
        resetPrinter();
        return messageData;
    }

    public void addImageFile(){
        addESC();
        addText("*r0f" + translator.getWidth() + "s" + translator.getHeight() + "T");
        addESC();
        addText("*t" + translator.getWidth() * (9.6 *xScale) + "h" + translator.getHeight()*(9.6 * yScale) + "V");
        addESC();
        addText("*r3A");
        addESC();
        addText("*b0M"); //Mode: unecode
        translator.addPCLImage(this);
    }

    public void addPosition(){ //byte size!
        int[] pos = {xPosition, yPosition};
        String[] axis = {"X","Y"};

        for (int i=0; i<2; i++){
            addESC();
            addText("*p" + pos[i] + axis[i]);
        }
    }

    public void addPageSize(){
        addESC();
        add(38);    // & ascii
        add(108);   // l ascii
        addText(Integer.toString(pageSize)); // format
        add(65);    // A ascii
    }

    public void addUnitOfMeasure(){
        addESC();
        addText("&u" + unitOfMeasure + "D");
    }

    public void addConfigureImageData(){
        addESC();
        addText("*v"+6+"W");
        for (int i = 0; i<6; i++){
            add(dataImage[i]);
        }
    }

    public void addDotsPerInch(){
        addESC();
        addText("*t" + dotsPerInch + "R");
    }

    public void resetPrinter(){
        addESC();
        add(69);  // E ascii
    }

    public Translator getTranslator(){
        return translator;
    }

}
